/**
 * Spine artwork loader
 * ---------------------
 * */

document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.spine-artwork').forEach(initSpineArtwork);
});




function initSpineArtwork(container) {

  const baseDir = container.dataset.spineDir;
  const jsonFile = container.dataset.spineJson;
  const atlasFile = container.dataset.spineAtlas;
  const fitMode = container.dataset.spineFit || 'contain';
  
  const forcedWidth = container.parentElement.getBoundingClientRect().width;
  const forcedHeight = container.parentElement.getBoundingClientRect().height;
  let width = container.getBoundingClientRect().width;
  let height = container.getBoundingClientRect().height;
  console.log ("Original: " + width + " x " + height);
  console.log ("Forced: " + forcedWidth + " x " + forcedHeight);

  if (forcedWidth) {
    container.style.width = /^\d+$/.test(forcedWidth) ? `${forcedWidth}px` : forcedWidth;
    //container.style.aspectRatio = 'auto';
  }
  if (forcedHeight) {
    container.style.height = /^\d+$/.test(forcedHeight) ? `${forcedHeight}px` : forcedHeight;
    //container.style.aspectRatio = 'auto';
  }
  
  width = container.getBoundingClientRect().width;
  height = container.getBoundingClientRect().height;
  console.log ("Result: " + width + " x " + height);

  if (!baseDir || !jsonFile || !atlasFile) return;

  const assetBase = `../${baseDir}/`;
  console.log (assetBase + jsonFile);

  if (typeof spine === 'undefined' || !spine.SpinePlayer) {
    console.warn('Spine runtime not available, showing directory label instead.');
    return;
  }

  fetch(assetBase + jsonFile)
    .then((res) => {
      if (!res.ok) throw new Error('not found');
      return res.json();
    })
    .then((skeletonData) => {
      const animations = skeletonData.animations ? Object.keys(skeletonData.animations) : [];
      const skins = skeletonData.skins
        ? skeletonData.skins.map((s) => (typeof s === 'string' ? s : s.name))
        : [];

      if (!animations.length) {
        console.warn('Spine JSON loaded but contains no animations:', jsonFile);
        return;
      }

      const targetAnim = parseInt(container.dataset.spineAnim, 10) || 0;
      const firstAnimation = animations[targetAnim];
      
      const firstSkin = skins.length ? skins[0] : 'default';

      console.info(`Spine skeleton "${jsonFile}" — animations found:`, animations, '— using skin:', firstSkin);

      // By default, leave viewport sizing to the player: SpinePlayer.calculateAnimationViewport()
      // samples the whole animation across 100 timesteps and unions every bone's bounding box,
      // so it auto-zooms to keep the entire moving rig in frame. That's the correct, desired
      // behavior for most looping UI animations (a spinning wheel, a bouncing icon, a coin
      // that scales up) — the framing tracks the motion.
      //
      // A few skeletons (e.g. "Me fabulous") have some out-of-frame motion in their timeline
      // that inflates the auto-computed viewport into something much bigger than the actual
      // "card", making the artwork render tiny inside its container. For those specific cases,
      // opt in per-instance with data-spine-viewport="setup" on the container: this uses the
      // skeleton JSON header's static, editor-computed setup-pose bounding box
      // (skeletonData.skeleton.x/y/width/height) instead of the dynamic per-animation bounds.
      // Do NOT enable this by default — it clips animations whose motion legitimately extends
      // beyond the setup pose (e.g. daily-gift's coin scaling to ~2.9x, starter-pack's 240°
      // rotation, wheel's spin), cutting them off instead of framing them.
      const useSetupPoseBounds = container.dataset.spineViewport === 'setup';
      const skelHeader = skeletonData.skeleton || {};
      const hasExplicitBounds =
        useSetupPoseBounds &&
        typeof skelHeader.x === 'number' &&
        typeof skelHeader.y === 'number' &&
        typeof skelHeader.width === 'number' &&
        typeof skelHeader.height === 'number';

      if (useSetupPoseBounds && !hasExplicitBounds) {
        console.warn(`Spine skeleton "${jsonFile}" requested setup-pose bounds via data-spine-viewport="setup" but its header has no valid x/y/width/height — falling back to the player's auto-calculated viewport.`);
      } else if (hasExplicitBounds) {
        console.info(`Spine skeleton "${jsonFile}" — using explicit setup-pose bounds:`, {
          x: skelHeader.x, y: skelHeader.y, width: skelHeader.width, height: skelHeader.height,
        });
      }

      container.innerHTML = '';

      new spine.SpinePlayer(container, {
        jsonUrl: assetBase + jsonFile,
        atlasUrl: assetBase + atlasFile,
        alpha: true,
        showControls: false,
        backgroundColor: '#00000000',
        premultipliedAlpha: true,
        skin: firstSkin,
        animation: firstAnimation,
        loop: true,

        viewport: Object.assign(
          hasExplicitBounds
            ? { x: skelHeader.x, y: skelHeader.y, width: skelHeader.width, height: skelHeader.height }
            : {},
          fitMode === 'cover'
            ? { padLeft: '0%', padRight: '0%', padTop: '0%', padBottom: '0%' }
            : { padLeft: '5%', padRight: '5%', padTop: '5%', padBottom: '5%' }
        ),
        success: (player) => {
          console.info('Spine player mounted successfully.');
        },
        error: (player, msg) => {
          console.error('Spine player failed to load:', msg);
          
          container.innerHTML = `<div class="spine-artwork__fallback">${baseDir}</div>`;
        },
      });
    })
    .catch(() => {
      
    });
}
